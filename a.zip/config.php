<?php

// Edited by ThietkewebX.net

// Cấu hình kết nối dữ liệu
$hostname     = "localhost"; // Tên Host
$username     = "root"; // Tên user đăng nhập
$password     = ""; // Mật khẩu đăng nhập
$databasename = "vinhcv_truonghoc"; // Tên cơ sở dữ liệu, nếu không cấu hình đúng, sẽ ra trang trắng.

// Cấu hình hệ thống
$visitorTimeout = 900; //=15 * 60
$MAXPAGE = 10;
$multiLanguage = 1;//0 : single  ;  1 : multi

// Cấu hình ngôn ngữ.
$arrLanguage = array(
	array('vn','Việt Nam'),
	array('en','English')
);

?>

