<?php define('_HOME'            ,'Trang Chủ');
define('_INTRO'           ,'Giới Thiệu');
define('_SERVICE'		  ,'Dịch Vụ');
define('_PROMOTION'	 	  ,'Khuyến mãi');
define('_NEWS'			  ,'Tin tức &amp; Sự kiện');
define('_CONTACT'         ,'Liên Hệ');	
define('_DETAIL'		  ,'Xem Tiếp');
define('_PRICE'			  ,'Giá');
define('_CART'			  ,'Giỏ hàng');
define('_CATEGORY'		  ,'DANH MỤC CHÍNH');
define('_PARTNER'		  ,'Đối tác &amp; khách hàng');
define('_NEWS_'			  ,'TIN TỨC');
define('_TOTALS'		  ,'Xem tất cả');
//--------------------------Danh mục sp----------------------------------------
define('_INFOMATION'       ,'THÔNG TIN CẦN BIẾT');
define('_SUPPORTONLINE'    ,'HỖ TRỢ TRỰC TUYẾN');
define('_MEMBER'           ,'THÀNH VIÊN');
define('_TOTAL'            ,'THỐNG KÊ TRUY CẬP');
//-------------------------SP--------------------------------------------------
define('_PRODUCTNEW'	   ,'SẢN PHẨM MỚI');
define('_PRODUCT_CATEGORY' ,'DANH MỤC SẢN PHẨM');
//-----------------------------------------------------------------------------
define('_LINK'            ,'Liên kết website');
define('_WEATHER'         ,'Thời tiết');
define('_GOLD'            ,'Giá vàng');
define('_FOREX'           ,'Tỷ giá ngoại tệ');

define('_SUPPORT_ONLINE'  ,'Hỗ trợ trực tuyến');
define('_SEARCH'          ,'TÌM KIẾM');
//define('_DETAIL'		  ,'Chi tiết');
define('_UID'             ,'Tên đăng nhập');
define('_PWD'             ,'Mật khẩu');
define('_REGISTRY'        ,'Đăng ký thành viên mới !');
define('_LOGIN'           ,'Đăng nhập');
define('_LOGOUT'          ,'Đăng Xuất');
define('_FORGOTPASS'      ,'Quên mật khẩu !');
define('_ACCOUNT'         ,'Tài khoản');

//---------------------------------------------------------------------------

?>
